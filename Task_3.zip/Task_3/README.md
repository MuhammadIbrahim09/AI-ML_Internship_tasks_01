# 🤖 RAG Chatbot — Complete Setup Guide

## What This Project Does

A conversational chatbot that:
- **Reads** your custom text documents (knowledge base)
- **Embeds** them into a FAISS vector store using OpenAI embeddings
- **Retrieves** relevant chunks when you ask a question (RAG)
- **Generates** a context-aware answer using GPT-3.5-turbo
- **Remembers** the last 6 turns of conversation (sliding window memory)
- **Shows** which source documents were used for each answer

---

## 📁 Project Structure

```
rag_chatbot/
├── app.py               ← Main Streamlit application
├── requirements.txt     ← Python dependencies
├── .env.example         ← API key template
├── .env                 ← Your actual API key (create this yourself)
└── data/                ← Your knowledge base (put .txt files here)
    ├── artificial_intelligence.txt
    ├── python_programming.txt
    └── data_science.txt
```

---

## 🖥️ WHERE TO RUN THIS — Recommended: VS Code / Terminal (Local)

> **Best choice for this project:** Run locally on your PC. Streamlit is a web app — it needs a persistent server, which Jupyter Notebook and Google Colab don't support well.

### ✅ Option 1: Local PC with VS Code (RECOMMENDED)

**Step 1 — Install Python**
Download Python 3.10 or 3.11 from https://python.org/downloads
During installation on Windows, check ✅ "Add Python to PATH"

**Step 2 — Install VS Code**
Download from https://code.visualstudio.com
Install the Python extension inside VS Code

**Step 3 — Download / Clone the Project**
Place the project folder anywhere, e.g. `C:\Users\YourName\rag_chatbot`

**Step 4 — Open Terminal in the Project Folder**
In VS Code: Terminal → New Terminal
Or: Right-click the folder → Open in Terminal

**Step 5 — Create a Virtual Environment**
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac / Linux
python3 -m venv venv
source venv/bin/activate
```
You should see `(venv)` at the start of your terminal prompt.

**Step 6 — Install Dependencies**
```bash
pip install -r requirements.txt
```
This installs all required packages. Takes 2–5 minutes.

**Step 7 — Set Up Your API Key**
Create a file named `.env` in the project folder:
```
OPENAI_API_KEY=sk-your-actual-key-here
```
(Copy `.env.example`, rename it `.env`, paste your key)

**Step 8 — Run the App**
```bash
streamlit run app.py
```
Your browser will open automatically at http://localhost:8501

---

### ✅ Option 2: Google Colab (with ngrok tunnel)

Colab doesn't natively support Streamlit, but you can use ngrok to expose it.

**Step 1 — Open a new Colab notebook at colab.research.google.com**

**Step 2 — Upload your project files using the Files panel on the left**

**Step 3 — Run these cells:**

```python
# Cell 1: Install dependencies
!pip install streamlit langchain langchain-openai langchain-community \
             openai faiss-cpu python-dotenv tiktoken pyngrok -q
```

```python
# Cell 2: Set your API key
import os
os.environ["OPENAI_API_KEY"] = "sk-your-key-here"  # paste your key
```

```python
# Cell 3: Create the data folder and upload documents
!mkdir -p data
# Upload your .txt files to the data/ folder using the Files panel
```

```python
# Cell 4: Start Streamlit with ngrok
from pyngrok import ngrok
import subprocess, time

# Start Streamlit in background
proc = subprocess.Popen(["streamlit", "run", "app.py",
                         "--server.port", "8501",
                         "--server.headless", "true"])
time.sleep(5)

# Create public tunnel
tunnel = ngrok.connect(8501)
print(f"\n🚀 Open your chatbot at: {tunnel.public_url}\n")
```

**Note:** The free ngrok tier gives a public URL valid for the Colab session. Sign up at ngrok.com for a free auth token to remove the time limit.

---

## 📚 Adding Your Own Documents

1. Create any `.txt` files and put them in the `data/` folder
2. Examples of good knowledge bases:
   - Wikipedia articles saved as .txt
   - Company policy documents
   - Textbook chapters
   - Research paper summaries
   - FAQ documents
3. Restart the app and click **"Load / Reload Documents"** in the sidebar

---

## 🔑 Getting Your OpenAI API Key

1. Go to https://platform.openai.com
2. Sign in with your student account
3. Navigate to API → API Keys
4. Click "Create new secret key"
5. Copy and paste it into your `.env` file

**Cost estimate:** GPT-3.5-turbo costs ~$0.002 per 1K tokens. For testing this project, expect to spend less than $0.50 total.

---

## 🏗️ How RAG Works (for your internship report)

```
User Question
     │
     ▼
┌─────────────────────────┐
│   Question Embedding    │  ← Convert question to vector
│   (OpenAI Embeddings)   │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│   FAISS Vector Search   │  ← Find top-4 similar chunks
│   (Similarity Search)   │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│   Context Assembly      │  ← Retrieved chunks + chat history
│   (LangChain Chain)     │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│   GPT-3.5-turbo         │  ← Generate answer with context
│   (Answer Generation)   │
└──────────┬──────────────┘
           │
           ▼
     Final Answer + Sources
```

---

## 🐛 Troubleshooting

| Error | Fix |
|-------|-----|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` again |
| `AuthenticationError` | Check your API key in `.env` |
| `No .txt files found` | Make sure files are in the `data/` folder |
| Port already in use | Run `streamlit run app.py --server.port 8502` |
| Streamlit not found | Make sure your venv is activated |

---

## 📝 Skills You'll Demonstrate

- ✅ **RAG Pipeline:** Document loading → embedding → vector search → answer generation
- ✅ **Conversational Memory:** Sliding window memory (last 6 turns)
- ✅ **Vector Store:** FAISS for fast similarity search
- ✅ **LLM Integration:** OpenAI GPT-3.5-turbo via LangChain
- ✅ **Deployment:** Streamlit web application
- ✅ **Source Attribution:** Shows which documents were retrieved

import streamlit as st
import os
from dotenv import load_dotenv

load_dotenv()

try:
    from langchain_huggingface import HuggingFaceEmbeddings
except ImportError:
    try:
        from langchain_community.embeddings import HuggingFaceEmbeddings
    except ImportError:
        st.error("❌ Run: pip install langchain-huggingface sentence-transformers"); st.stop()

try:
    from langchain_community.vectorstores import FAISS
    from langchain_community.document_loaders import TextLoader, DirectoryLoader
except ImportError:
    st.error("❌ Run: pip install langchain-community faiss-cpu"); st.stop()

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    try:
        from langchain.text_splitter import RecursiveCharacterTextSplitter
    except ImportError:
        st.error("❌ Run: pip install langchain-text-splitters"); st.stop()

try:
    from groq import Groq
except ImportError:
    st.error("❌ Run: pip install groq"); st.stop()

# ── Page Config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="RAG Chatbot | AI Assistant",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Light Theme CSS ───────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

* { font-family: 'Inter', sans-serif !important; box-sizing: border-box; }

.stApp {
    background: linear-gradient(145deg, #f0f4ff 0%, #faf5ff 50%, #f0f9ff 100%);
    min-height: 100vh;
    color: #1e293b;
}

[data-testid="stSidebar"] {
    background: white !important;
    border-right: 1px solid #e2e8f0 !important;
    box-shadow: 4px 0 20px rgba(99,102,241,0.08) !important;
}
[data-testid="stSidebar"] * { color: #1e293b !important; }

[data-testid="stSidebar"] input {
    background: #f8fafc !important;
    border: 1.5px solid #e2e8f0 !important;
    border-radius: 10px !important;
    color: #1e293b !important;
    padding: 10px 14px !important;
}
[data-testid="stSidebar"] input:focus {
    border-color: #6366f1 !important;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.12) !important;
}

.stButton > button {
    background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 11px 20px !important;
    font-weight: 600 !important;
    font-size: 0.9rem !important;
    transition: all 0.25s ease !important;
    width: 100%;
    box-shadow: 0 4px 14px rgba(99,102,241,0.25) !important;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #4f46e5, #7c3aed) !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 8px 22px rgba(99,102,241,0.35) !important;
}

[data-testid="stFormSubmitButton"] > button {
    background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
    color: white !important;
    border: none !important;
    border-radius: 12px !important;
    font-weight: 600 !important;
    width: 100% !important;
    box-shadow: 0 4px 14px rgba(99,102,241,0.3) !important;
}

[data-testid="stTextInput"] input {
    background: white !important;
    border: 2px solid #e2e8f0 !important;
    border-radius: 14px !important;
    color: #1e293b !important;
    padding: 14px 20px !important;
    font-size: 1rem !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05) !important;
}
[data-testid="stTextInput"] input:focus {
    border-color: #6366f1 !important;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.15) !important;
}
[data-testid="stTextInput"] input::placeholder { color: #94a3b8 !important; }

/* Chat bubbles */
.user-bubble {
    display:flex; justify-content:flex-end; align-items:flex-end;
    gap:10px; margin:18px 0;
    animation: fadeSlideRight 0.3s ease;
}
.user-bubble-inner {
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: white;
    padding: 14px 20px;
    border-radius: 20px 20px 4px 20px;
    max-width: 68%;
    font-size: 0.95rem;
    line-height: 1.65;
    box-shadow: 0 6px 20px rgba(99,102,241,0.25);
}
.ai-bubble {
    display:flex; justify-content:flex-start; align-items:flex-start;
    gap:10px; margin:18px 0;
    animation: fadeSlideLeft 0.3s ease;
}
.ai-bubble-inner {
    background: white;
    color: #1e293b;
    padding: 16px 20px;
    border-radius: 20px 20px 20px 4px;
    max-width: 72%;
    font-size: 0.95rem;
    line-height: 1.75;
    border: 1.5px solid #e2e8f0;
    box-shadow: 0 4px 16px rgba(0,0,0,0.07);
}
.avatar {
    width:38px; height:38px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:0.85rem; font-weight:700; flex-shrink:0;
    box-shadow:0 2px 8px rgba(0,0,0,0.12);
}
.user-avatar { background:linear-gradient(135deg,#6366f1,#8b5cf6); color:white; }
.ai-avatar   { background:linear-gradient(135deg,#0ea5e9,#38bdf8); color:white; }

.source-chips { margin-top:12px; display:flex; flex-wrap:wrap; gap:6px; }
.source-chip {
    background:#f0f4ff; color:#6366f1;
    font-size:0.72rem; padding:4px 12px;
    border-radius:20px; border:1px solid #c7d2fe; font-weight:500;
}

.main-header { text-align:center; padding:28px 0 8px 0; }
.main-title {
    font-size:2.6rem; font-weight:800;
    background:linear-gradient(135deg,#6366f1,#8b5cf6,#0ea5e9);
    -webkit-background-clip:text; -webkit-text-fill-color:transparent;
    background-clip:text; margin-bottom:8px; letter-spacing:-0.02em;
}
.main-subtitle { color:#64748b; font-size:1rem; }

.custom-divider {
    border:none; height:1.5px;
    background:linear-gradient(90deg,transparent,#c7d2fe,#e9d5ff,transparent);
    margin:18px 0;
}

.status-card {
    background:linear-gradient(135deg,#f0fdf4,#dcfce7);
    border:1.5px solid #86efac;
    border-radius:12px; padding:14px 16px;
    margin:10px 0; font-size:0.88rem;
    line-height:1.9; color:#166534;
}

.step-item {
    display:flex; align-items:center; gap:10px;
    padding:7px 0; font-size:0.85rem; color:#64748b;
}
.step-num {
    background:linear-gradient(135deg,#6366f1,#8b5cf6);
    color:white; width:24px; height:24px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:0.72rem; font-weight:700; flex-shrink:0;
}

.welcome-box { text-align:center; padding:70px 40px; }
.welcome-icon { font-size:4.5rem; margin-bottom:18px; }
.welcome-title { font-size:1.4rem; color:#475569; font-weight:700; margin-bottom:10px; }
.welcome-sub   { font-size:0.92rem; color:#94a3b8; line-height:1.7; }
.suggestions   { display:flex; flex-wrap:wrap; gap:10px; justify-content:center; margin-top:24px; }
.suggestion-chip {
    background:white; color:#6366f1;
    border:1.5px solid #c7d2fe; border-radius:20px;
    padding:8px 18px; font-size:0.85rem; font-weight:500;
    box-shadow:0 2px 8px rgba(99,102,241,0.1);
}

@keyframes fadeSlideRight {
    from { opacity:0; transform:translateX(16px); }
    to   { opacity:1; transform:translateX(0); }
}
@keyframes fadeSlideLeft {
    from { opacity:0; transform:translateX(-16px); }
    to   { opacity:1; transform:translateX(0); }
}

::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:#f8fafc; }
::-webkit-scrollbar-thumb { background:#c7d2fe; border-radius:3px; }

#MainMenu, footer, header { visibility:hidden; }
</style>
""", unsafe_allow_html=True)

# ── Session State ─────────────────────────────────────────────────────────────
for k, v in {
    "messages": [], "vectorstore": None,
    "doc_count": 0, "chunk_count": 0,
    "ready": False, "groq_key": "",
}.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ── Vectorstore ───────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def build_vectorstore(data_dir="data"):
    embeddings = HuggingFaceEmbeddings(
        model_name="all-MiniLM-L6-v2",
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )
    loader = DirectoryLoader(
        data_dir, glob="**/*.txt",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"},
    )
    docs = loader.load()
    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=150)
    chunks = splitter.split_documents(docs)
    vs = FAISS.from_documents(chunks, embeddings)
    return vs, len(docs), len(chunks)


# ── RAG Answer ────────────────────────────────────────────────────────────────
def get_answer(question, vectorstore, groq_key, history):
    retrieved = vectorstore.similarity_search(question, k=4)
    context   = "\n\n---\n\n".join([d.page_content for d in retrieved])
    sources   = list({os.path.basename(d.metadata.get("source","unknown")) for d in retrieved})

    history_text = ""
    for msg in history[-12:]:
        role = "User" if msg["role"] == "user" else "Assistant"
        history_text += f"{role}: {msg['content']}\n"

    system = (
        "You are a knowledgeable and friendly AI assistant. "
        "Answer questions clearly and thoroughly based on the provided context. "
        "Use bullet points or numbered lists when helpful. Be warm and professional."
    )
    prompt = f"""Context:\n{context}\n\n"""
    if history_text.strip():
        prompt += f"Conversation history:\n{history_text}\n\n"
    prompt += f"Question: {question}\n\nAnswer:"

    client   = Groq(api_key=groq_key)
    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": prompt},
        ],
        temperature=0.4,
        max_tokens=1500,
    )
    return response.choices[0].message.content.strip(), sources


# ── SIDEBAR ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='text-align:center;padding:20px 0 14px 0;border-bottom:1px solid #f1f5f9;margin-bottom:16px;'>
        <div style='font-size:2.2rem;'>🧠</div>
        <div style='font-size:1.05rem;font-weight:700;color:#6366f1;margin-top:6px;'>RAG Chatbot</div>
        <div style='font-size:0.75rem;color:#94a3b8;margin-top:3px;'>AI Knowledge Assistant</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<p style='font-size:0.78rem;font-weight:600;color:#94a3b8;letter-spacing:0.07em;margin-bottom:6px;'>🔑 GROQ API KEY</p>", unsafe_allow_html=True)
    groq_key = st.text_input(
        "groq", type="password",
        placeholder="gsk_••••••••••••••••",
        value=os.getenv("GROQ_API_KEY", ""),
        label_visibility="collapsed",
    )
    st.markdown(
        "<p style='font-size:0.75rem;color:#6366f1;margin-top:4px;'>"
        "✨ Free at <a href='https://console.groq.com' target='_blank' "
        "style='color:#8b5cf6;font-weight:600;'>console.groq.com</a></p>",
        unsafe_allow_html=True
    )

    st.markdown("<hr style='border:none;height:1px;background:#f1f5f9;margin:16px 0;'>", unsafe_allow_html=True)
    st.markdown("<p style='font-size:0.78rem;font-weight:600;color:#94a3b8;letter-spacing:0.07em;margin-bottom:10px;'>📚 KNOWLEDGE BASE</p>", unsafe_allow_html=True)

    if st.button("⚡  Load Documents", use_container_width=True):
        if not groq_key:
            st.error("⚠️ Enter your Groq API key first!")
        elif not os.path.exists("data") or not any(f.endswith(".txt") for f in os.listdir("data")):
            st.error("⚠️ No .txt files in data/ folder!")
        else:
            with st.spinner("Building knowledge base…"):
                try:
                    vs, dc, cc = build_vectorstore("data")
                    st.session_state.update(
                        vectorstore=vs, doc_count=dc, chunk_count=cc,
                        ready=True, groq_key=groq_key, messages=[],
                    )
                    st.success("✅ Ready to chat!")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")

    if st.session_state.ready:
        st.markdown(f"""
        <div class="status-card">
            ✅ <b>Knowledge Base Active</b><br>
            📄 Documents: <b>{st.session_state.doc_count}</b><br>
            🧩 Chunks: <b>{st.session_state.chunk_count}</b><br>
            🤖 Model: <b>Llama 3.3 70B</b><br>
            🧠 Memory: <b>6 turns</b>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("<hr style='border:none;height:1px;background:#f1f5f9;margin:16px 0;'>", unsafe_allow_html=True)
        st.markdown("<p style='font-size:0.78rem;font-weight:600;color:#94a3b8;letter-spacing:0.07em;margin-bottom:8px;'>🚀 QUICK START</p>", unsafe_allow_html=True)
        st.markdown("""
        <div class="step-item"><div class="step-num">1</div><span>Enter your Groq API key</span></div>
        <div class="step-item"><div class="step-num">2</div><span>Add .txt files to data/</span></div>
        <div class="step-item"><div class="step-num">3</div><span>Click Load Documents</span></div>
        <div class="step-item"><div class="step-num">4</div><span>Start chatting!</span></div>
        """, unsafe_allow_html=True)

    st.markdown("<hr style='border:none;height:1px;background:#f1f5f9;margin:16px 0;'>", unsafe_allow_html=True)
    if st.session_state.messages:
        if st.button("🗑️  Clear Conversation", use_container_width=True):
            st.session_state.messages = []
            st.rerun()

    st.markdown("""
    <div style='text-align:center;margin-top:20px;'>
        <p style='font-size:0.72rem;color:#cbd5e1;line-height:1.8;'>
            Groq · LangChain · FAISS · HuggingFace<br>
            <span style='color:#a5b4fc;font-weight:600;'>Internship Project 2025</span>
        </p>
    </div>
    """, unsafe_allow_html=True)


# ── MAIN ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <div class="main-title">🧠 RAG Chatbot</div>
    <div class="main-subtitle">Retrieval-Augmented Generation · Groq Llama 3.3 · 100% Free</div>
</div>
""", unsafe_allow_html=True)
st.markdown("<hr class='custom-divider'>", unsafe_allow_html=True)

if not st.session_state.messages:
    st.markdown("""
    <div class="welcome-box">
        <div class="welcome-icon">💬</div>
        <div class="welcome-title">Welcome to your AI Knowledge Assistant</div>
        <div class="welcome-sub">
            Load your documents from the sidebar, then ask anything.<br>
            The AI retrieves relevant information and answers in context.
        </div>
        <div class="suggestions">
            <span class="suggestion-chip">📖 What is AI?</span>
            <span class="suggestion-chip">🐍 Explain Python</span>
            <span class="suggestion-chip">📊 What is Data Science?</span>
            <span class="suggestion-chip">🤖 How does RAG work?</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
else:
    for msg in st.session_state.messages:
        if msg["role"] == "user":
            st.markdown(f"""
            <div class="user-bubble">
                <div class="user-bubble-inner">{msg["content"]}</div>
                <div class="avatar user-avatar">U</div>
            </div>""", unsafe_allow_html=True)
        else:
            chips = ""
            if msg.get("sources"):
                chips = '<div class="source-chips">' + "".join(
                    f'<span class="source-chip">📄 {s}</span>' for s in msg["sources"]
                ) + '</div>'
            st.markdown(f"""
            <div class="ai-bubble">
                <div class="avatar ai-avatar">AI</div>
                <div class="ai-bubble-inner">
                    {msg["content"].replace(chr(10), "<br>")}
                    {chips}
                </div>
            </div>""", unsafe_allow_html=True)

st.markdown("<hr class='custom-divider'>", unsafe_allow_html=True)
with st.form("chat_form", clear_on_submit=True):
    c1, c2 = st.columns([6, 1])
    with c1:
        user_input = st.text_input("q", label_visibility="collapsed",
                                   placeholder="💭  Ask anything about your documents…")
    with c2:
        send = st.form_submit_button("Send ➤", use_container_width=True)

if send and user_input.strip():
    if not st.session_state.ready:
        st.warning("⚠️ Please load the knowledge base first from the sidebar.")
    else:
        st.session_state.messages.append({"role": "user", "content": user_input.strip()})
        with st.spinner("🤔 Thinking…"):
            try:
                answer, sources = get_answer(
                    user_input.strip(),
                    st.session_state.vectorstore,
                    st.session_state.groq_key,
                    st.session_state.messages[:-1],
                )
                st.session_state.messages.append({
                    "role": "assistant", "content": answer, "sources": sources,
                })
            except Exception as e:
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": f"⚠️ Error: {str(e)}",
                    "sources": [],
                })
        st.rerun()
